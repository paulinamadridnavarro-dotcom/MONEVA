---
name: laboratorio-estadistico
description: Integra a cualquier proyecto (app web, Python, R o Excel) un Laboratorio estadístico con fichas que calculan, explican e interpretan estadígrafos con los datos del propio proyecto, con un motor propio validado contra SciPy o R. Úsala cuando un estudiante de estadística aplicada pida agregar el análisis estadístico, el laboratorio o las fichas estadísticas a su proyecto.
---

# Laboratorio estadístico para proyectos de estudiantes

Esta skill guía la integración de una sección llamada "Laboratorio estadístico" en el proyecto de un estudiante de la asignatura de Estadística aplicada (maestría en finanzas). Cada proyecto es distinto; la skill adapta las fichas a los datos que el proyecto ya maneja. El modelo de referencia es Moneva, una aplicación de finanzas personales con once fichas.

El objetivo es pedagógico: el estudiante debe terminar entendiendo cada estadígrafo aplicado a sus datos. Claude construye y explica; el estudiante decide, revisa y demuestra que entiende.

## Fase 0. Datos del proyecto

Antes de empezar, confirma que tienes estos datos. Si falta alguno, pregúntalo en un solo mensaje:

- Nombre y descripción breve del proyecto.
- Tecnología: app web (HTML/JS), Python, R, Excel u otra.
- Variables que registra el proyecto: nombre, tipo (numérica, categórica, fecha), unidades y frecuencia (diaria, mensual, por cliente, etc.).
- Archivos del proyecto (adjuntos o en la carpeta de trabajo).

## Fase 1. Inspección y plan (detente al final)

1. Lee los archivos del proyecto. Identifica: la serie de tiempo principal, la variable categórica principal, la variable de riesgo, una razón propia del proyecto, un indicador financiero propio y la variable clave para simular.
2. Presenta una tabla con tres columnas: Ficha, Variable del proyecto que usará, Comentario. Marca las fichas que no aplican, explica por qué y propone una alternativa del mismo tema de la asignatura.
3. Si el proyecto no tiene datos, propone un conjunto de datos de demostración realista para su tema, marcado como ficticio. Nunca presentes datos inventados como reales.
4. **Espera el visto bueno del estudiante antes de programar.**

## Fase 2. Construcción

### Estructura de cada ficha (siempre en este orden)

1. **Qué mide:** una o dos líneas en lenguaje llano.
2. **Resultado:** tabla o indicadores; una gráfica cuando ayude.
3. **Interpretación:** texto generado a partir del resultado, con las cifras del proyecto. Dice qué significa para ese caso.
4. **Fórmula y cálculo con los datos:** notación de la asignatura (x̄, s, Me, n) y desarrollo paso a paso con los números del proyecto. En descriptivos, incluye la tabla de desviaciones (xᵢ − x̄)² con su suma.
5. **Supuestos y límites:** qué supone el método y cuándo no confiar en el resultado.

### Las once fichas

| # | Ficha | Contenido mínimo |
|---|---|---|
| 1 | Descriptiva | n, x̄, Me, s (n − 1), CV = s/x̄, mín., máx., rango, asimetría g₁ ajustada (como Excel COEFICIENTE.ASIMETRIA). Compara el CV de dos variables si existen. |
| 2 | Atípicos | z = (x − x̄)/s con umbral 2; z robusto = 0.6745·(x − Me)/MAD con umbral 2.5 (Leys et al., 2013); cercas de Tukey Q₁ − 1.5·RIC y Q₃ + 1.5·RIC. Si un método detecta lo que otro no, explica el efecto de enmascaramiento. |
| 3 | Intervalo de confianza | IC 95% = x̄ ± t₀.₀₂₅,ₙ₋₁ · s/√n. Calcúlalo con todos los datos y sin los extraordinarios, si tiene sentido separarlos. Muestra EE, t y margen. |
| 4 | Pareto | Porcentaje y porcentaje acumulado por categoría; clase A hasta cruzar 80%, B hasta 95%, C el resto. |
| 5 | Variabilidad relativa | CV por categoría o grupo: estable < 10%, moderada 10% a 30%, variable > 30%. Advierte que una categoría con un solo dato distinto de cero tiene CV alto por construcción. |
| 6 | Tendencia | Regresión ŷ = a + b·t con b, EE(b), t, p y R²; ρ de Spearman por categoría con su p (aproximación t, la misma de SciPy). |
| 7 | Asociación y contraste | r de Pearson con p y r crítica = t/√(t² + n − 2); t de Welch entre dos periodos o grupos con gl de Welch-Satterthwaite. |
| 8 | Razones | Una razón propia del proyecto (margen, tasa de ahorro, rotación). Compara media de las razones, mediana y razón agregada Σnumerador/Σdenominador. |
| 9 | Percentiles | P90 empírico (método 7) y P90 normal = x̄ + 1.2816·s de la variable de riesgo. Lectura tipo "valor en riesgo". Permite elegir 90, 95 o 99%. |
| 10 | Indicador financiero | Uno propio del proyecto: tasa efectiva (1 + i)¹² − 1, valor presente, rendimiento o costo. Si hay tasas de tarjetas en México, considera el IVA de 16% sobre intereses. |
| 11 | Monte Carlo | Simulación de la variable clave con generador con semilla y Box-Muller; percentiles 10, 50 y 90 por periodo, probabilidad de alcanzar una meta y comparación con el escenario determinista. Con σ = 0 debe reproducir el determinista. |

### Reglas técnicas

- **Motor propio**, sin bibliotecas externas de estadística en el código final. Convenciones obligatorias:
  - Desviación estándar muestral con n − 1.
  - Cuantiles con el método 7 (Excel PERCENTIL.INC, R type 7, NumPy por defecto).
  - Valores p de t con la beta incompleta regularizada: p bilateral = I(gl/(gl + t²); gl/2, 1/2).
  - Valor t crítico por bisección sobre esa función.
  - Normal inversa con el algoritmo de Acklam.
  - Spearman con rangos promedio en empates.
  - Generador con semilla (por ejemplo mulberry32) y Box-Muller.
- Si la skill incluye `referencias/motor-estadistico.js`, úsalo como implementación de referencia (ya validada) y adáptalo al lenguaje del proyecto.
- **Plataforma:**
  - App web: una sección más del menú, sin dependencias en línea.
  - Python o R: un módulo o cuaderno con una función por ficha y una función que genere el reporte.
  - Excel: una hoja nueva con fórmulas visibles (PROMEDIO, MEDIANA, DESVEST.M, PERCENTIL.INC, DISTR.T.2C, INV.T.2C).
- Permite elegir el periodo o subconjunto analizado.
- Con n < 3 no calcules las fichas y explica por qué. Con n < 12 muestra una advertencia de baja potencia.
- Exporta a CSV los datos que usa el laboratorio.
- **Interpretaciones:** sin lenguaje causal ("provoca", "genera"); usa "se asocia", "fue mayor en". Escribe "significativo" solo si la prueba lo es. Un resultado no significativo con n pequeño no demuestra que el efecto no exista.
- Escapa cualquier texto que venga de los datos antes de mostrarlo en una página web.

## Fase 3. Validación (obligatoria)

Compara cada resultado del motor con SciPy (o con R) usando los datos del proyecto. Si puedes ejecutar código, hazlo tú. Si no puedes, entrega el script al estudiante para que lo corra. Plantilla:

```python
import numpy as np
from scipy import stats
x = np.array([...])          # serie principal del proyecto
t = np.arange(1, len(x) + 1)
print("t crítico", stats.t.ppf(.975, len(x) - 1))
print("asimetría", stats.skew(x, bias=False))
print("cuartiles", np.percentile(x, [25, 75]))
print("regresión", stats.linregress(t, x))
print("Pearson", stats.pearsonr(y, x))            # y: segunda variable
print("Spearman", stats.spearmanr(t, z))          # z: serie de una categoría
print("Welch", stats.ttest_ind(b, a, equal_var=False))
n = len(x); tc = stats.t.ppf(.975, n - 2); print("r crítica", tc / np.sqrt(tc**2 + n - 2))
```

Entrega una tabla con tres columnas: Resultado, Valor del proyecto, Valor de SciPy o R. Deben coincidir por lo menos hasta el tercer decimal. Si algo no coincide, corrige antes de entregar y explica qué estaba mal.

## Fase 4. Entrega

1. Archivos nuevos o modificados, con una línea por archivo que diga qué cambió.
2. Tabla de validación.
3. Resumen de una página: cada ficha, su resultado principal con los datos del proyecto y su interpretación.
4. Tres preguntas para comprobar que el estudiante entiende sus propios resultados.

## Fase 5. Comprensión del estudiante (integridad académica)

Al final, elige tres fichas y pide al estudiante que explique con sus palabras: qué calcula, qué supone y qué significa el resultado en su proyecto. Revisa su explicación, señala errores y dale pistas. **No escribas la explicación por él**, aunque lo pida; ofrece en cambio una pregunta guía.

## Errores comunes que debes evitar

- Usar n en lugar de n − 1 en la desviación estándar.
- Usar cuantiles de otro método y obtener cuartiles distintos a Excel.
- Reportar el z clásico como único criterio de atípicos.
- Promediar porcentajes sin comparar con la razón agregada.
- Decir que una prueba "demuestra" algo o interpretar causalidad en datos observacionales.
- Mostrar un solo escenario en una simulación sin sus percentiles.

## Referencias

- Leys, C., Ley, C., Klein, O., Bernard, P., y Licata, L. (2013). Detecting outliers: Do not use standard deviation around the mean, use absolute deviation around the median. *Journal of Experimental Social Psychology, 49*(4), 764–766.
- Virtanen, P., et al. (2020). SciPy 1.0: Fundamental algorithms for scientific computing in Python. *Nature Methods, 17*, 261–272.
